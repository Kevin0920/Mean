var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, './client/static')));
app.set('views', path.join(__dirname, './client/views'));
app.set('view engine', 'ejs');

// require the mongoose configuration file which does the reset for us
require('./server/config/mongoose.js');

// the two lines below are the main changes to start modularization
// first, we store the function in a var
var routes_setter = require('./server/config/routes.js');
// we then invoke the function stored in routes_setter and pass it the "app" variable
routes_setter(app);

// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})






app.get('/mongooses/:id', function(req, res){
    Animal.findOne({_id: req.params.id}, function(err, animal){
        if(!err){
            console.log("it works for a specific id!");
            console.log(animal);
            res.render('show', {animal:animal});
        }
    })
});
//show a form to edit an existing mongoose
app.get('/mongooses/:id/edit', function(req, res){
    Animal.findOne({_id: req.params.id}, function(err, animal){
        if(!err){
            console.log("Working?");
            res.render('edit', {animal:animal});
        }
    })
});
//the action attribute for the form in the above Routes
app.post('/mongooses/:id', function(req, res){
    Animal.findOne({_id: req.body.id}, function(err, animal){
        animal.name = req.body.name;
        animal.age = req.body.age;
        animal.type = req.body.type;
        animal.save(function(err){
            if(!err){
                console.log("update successfully!");
                res.redirect('/')
            }
        })
    })
});
//delete the mongoose from the database by ID
app.post('/mongooses/:id/destroy', function(req,res){
    Animal.remove({_id: req.params.id}, function(err){
        if(!err){
            console.log("successfully deleted!");
            res.redirect('/')
        }
    })
});
