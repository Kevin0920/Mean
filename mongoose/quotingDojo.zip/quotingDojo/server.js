var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/quotingDojo');


var QuoteSchema = new mongoose.Schema({
    name: {type: String},
    quotes: {type: String, required: true, maxlength: 20}
}, {timestamps: true});
// Store the Schema under the name 'User'
mongoose.model('User', QuoteSchema);
// Retrieve the Schema called 'User' and store it to the variable User
var Quote = mongoose.model('User');

mongoose.Promise = global.Promise;


app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    res.render('index');
});

app.get('/quotes', function (req, res) {
    Quote.find({}).sort({'createdAt': -1}).exec(function(err, quotes) {
        res.render('quotes', {quotes: quotes});
    })
});

app.post('/quotes', function(req, res) {
    console.log("POST DATA", req.body);
    var quote = new Quote({name: req.body.name, quotes: req.body.quote});
    quote.save(function(err) {
        if(err){
            console.log('something went wrong');
            res.render('quotes');
        }
        else{
            console.log('successfully added a quoters!');
            res.redirect('/quotes');
        }
    })
});

app.get('/quotes', function(req, res) {
    var quotes = Quote.find({}, function (err, quotes) {
        console.log('quote passing!!!');
        if(err){
            console.log('somwthing went wrong');
        }
        else{
            console.log('successfully added a quote!');
            res.render('quotes', {quotes:quotes});
        }
    })
});





app.listen(8000, function() {
    console.log("listening on port 8000");
});
